<?php

$usr= $_POST ['name'];
$cpass= $_POST ['phone'];
$email= $_POST ['email'];
$pass= $_POST ['password'];
$chk= $_POST ['pwVerified'];
$phone=$_POST ['phone'];

echo "</br>Registration Sucessful !";
echo "</br>Your user name is : ".$usr;
echo "</br>Your Email: ".$email;
echo "</br>Your phone : ".$phone;
echo "</br>Your password: ".$pass;
echo "</br>Your password: ".$chk;



?>

